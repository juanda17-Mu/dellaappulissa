
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Cv della Appulisa">
    <meta name="author" content="TGD Application system">

    <title>Welcome To Point of Sale Apps</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url().'assets/css/bootstrap.min.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/style.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/font-awesome.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/4-col-portfolio.css'?>" rel="stylesheet">
    <style type="text/css">
    .bg {
        width: 100%;
        height: 100%;
        position: fixed;
        z-index: -1;
        float: left;
        left: 0;
        margin-top: -20px;
    }
    </style>
</head>

<body>
      <?php 
        $h = $this->session->userdata('akses'); 
        // Background dinamis berdasarkan role
        if($h == '2'){
            $bg_image = base_url().'assets/img/bg7.jpg'; // Gambar untuk kasir
        } else {
            $bg_image = base_url().'assets/img/bg2.jpg'; // Gambar default admin
        }
    ?>
    <img src="<?php echo $bg_image ?>" alt="gambar" class="bg" />


    <!-- Navigation -->
    <?php 
        $this->load->view('admin/menu');
    ?>

    <!-- Page Content -->
    <div class="container">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" 
    style="color: #ffd900ff; font-family: 'Palatino Linotype', serif;">
    Welcome to
    <small style="color: #382f07ff;">Aplikasi Penjualan</small>
</h1>

                </h1>
            </div>
        </div>

        <div class="mainbody-section text-center">
            <?php $h=$this->session->userdata('akses'); ?>
            <?php $u=$this->session->userdata('user'); ?>

            <div class="row">
                <?php if($h=='1'){ ?> 
                    <!-- Admin menu -->
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item blue" style="height:150px;">
                            <a href="<?php echo base_url().'admin/penjualan'?>">
                                <i class="fa fa-shopping-bag"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Penjualan Eceran</p>
                            </a>
                        </div> 
                    </div>
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item green" style="height:150px;">
                            <a href="<?php echo base_url().'admin/penjualan_grosir'?>">
                                <i class="fa fa-cubes"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Penjualan Grosir</p>
                            </a>
                        </div> 
                    </div>
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item light-orange" style="height:150px;">
                            <a href="<?php echo base_url().'admin/suplier'?>">
                                <i class="fa fa-truck"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Supplier</p> 
                            </a>
                        </div> 
                    </div>
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item color" style="height:150px;">
                            <a href="<?php echo base_url().'admin/kategori'?>">
                                <i class="fa fa-sitemap"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Kategori</p>
                            </a>
                        </div> 
                    </div>
                <?php } ?>

                <?php if($h=='2'){ ?> 
                    <!-- Kasir menu -->
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item  blue" style="height:150px;">
                            <a href="<?php echo base_url().'admin/penjualan'?>">
                                <i class="fa fa-shopping-cart"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Penjualan Eceran</p>
                            </a>
                        </div> 
                    </div>
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item green" style="height:150px;">
                            <a href="<?php echo base_url().'admin/penjualan_grosir'?>">
                                <i class="fa fa-cubes"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Penjualan Grosir</p>
                            </a>
                        </div> 
                    </div>
                    <div class="col-md-3 portfolio-item">
                        <div class="menu-item light-orange" style="height:150px;">
                            <a href="<?php echo base_url().'admin/suplier'?>">
                                <i class="fa fa-truck"></i>
                                <p style="text-align:left;font-size:18px;padding-left:5px;">Supplier</p>
                            </a>
                        </div> 
             
                <?php } ?>
            </div>

            <?php if($h=='1'){ ?>
            <div class="row">
                <!-- Menu untuk Admin lanjutan -->
                <div class="col-md-3 portfolio-item">
                    <div class="menu-item purple" style="height:150px;">
                        <a href="<?php echo base_url().'admin/barang'?>">
                            <i class="fa fa-shopping-cart"></i>
                            <p style="text-align:left;font-size:18px;padding-left:5px;">Barang</p>
                        </a>
                    </div> 
                </div>
                <div class="col-md-3 portfolio-item">
                    <div class="menu-item red" style="height:150px;">
                        <a href="<?php echo base_url().'admin/pengguna'?>">
                            <i class="fa fa-users"></i>
                            <p style="text-align:left;font-size:18px;padding-left:5px;">Pengguna</p>
                        </a>
                    </div> 
                </div>
                <div class="col-md-3 portfolio-item">
                    <div class="menu-item blue" style="height:150px;">
                        <a href="<?php echo base_url().'admin/laporan'?>">
                            <i class="fa fa-bar-chart"></i>
                            <p style="text-align:left;font-size:18px;padding-left:5px;">Laporan</p>
                        </a>
                    </div> 
                </div>
                <div class="col-md-3 portfolio-item">
                    <div class="menu-item light-red" style="height:150px;">
                        <a href="<?php echo base_url().'admin/pembelian'?>">
                            <i class="fa fa-cubes"></i>
                            <p style="text-align:left;font-size:18px;padding-left:5px;">Pembelian</p>
                        </a>
                    </div> 
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <!-- Footer -->
  <footer>
    Copyright By STMIK Triguna Dharma Medan 2025.
  </footer>

    <!-- JavaScript -->
    <script src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>

</html>