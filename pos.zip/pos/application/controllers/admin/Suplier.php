<?php
class Suplier extends CI_Controller{
    function __construct(){
        parent::__construct();
        if($this->session->userdata('masuk') != TRUE){
            $url=base_url();
            redirect($url);
        };
        $this->load->model('m_suplier');
    }

    // Kasir dan Admin boleh lihat halaman supplier
    function index(){
        if(in_array($this->session->userdata('akses'), ['1', '2'])){
            $data['data'] = $this->m_suplier->tampil_suplier();
            $this->load->view('admin/v_suplier', $data);
        } else {
            echo "Halaman tidak ditemukan";
        }
    }

    // Hanya admin yang bisa tambah
    function tambah_suplier(){
       if(in_array($this->session->userdata('akses'), ['1', '2'])){
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $notelp = $this->input->post('notelp');
            $this->m_suplier->simpan_suplier($nama, $alamat, $notelp);
            redirect('admin/suplier');
        } else {
            echo "Halaman tidak ditemukan";
        }
    }

    // Hanya admin yang bisa edit
    function edit_suplier(){
      if(in_array($this->session->userdata('akses'), ['1', '2'])){
            $kode = $this->input->post('kode');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $notelp = $this->input->post('notelp');
            $this->m_suplier->update_suplier($kode, $nama, $alamat, $notelp);
            redirect('admin/suplier');
        } else {
            echo "Halaman tidak ditemukan";
        }
    }

    // Hanya admin yang bisa hapus
    function hapus_suplier(){
        if(in_array($this->session->userdata('akses'), ['1', '2'])){
            $kode = $this->input->post('kode');
            $this->m_suplier->hapus_suplier($kode);
            redirect('admin/suplier');
        } else {
            echo "Halaman tidak ditemukan";
        }
    }
}
